import os
from Crypto.Cipher import AES

BLOCK = 16
COUNTER_MAX = (1 << (BLOCK * 8)) - 1

def aes_enc_block(key: bytes, block: bytes) -> bytes:
    assert len(block) == BLOCK
    return AES.new(key, AES.MODE_ECB).encrypt(block)

def xor(a: bytes, b: bytes) -> bytes:
    return bytes(x ^ y for x, y in zip(a, b))

def split_blocks(data: bytes) -> list[bytes]:
    return [data[i:i + BLOCK] for i in range(0, len(data), BLOCK)]

def _int_to_block(n: int) -> bytes:
    return (n % (1 << 128)).to_bytes(BLOCK, "big")

def ctr_encrypt(key: bytes, plaintext: bytes) -> bytes:
    iv = os.urandom(BLOCK)

    counter = int.from_bytes(iv, "big")
    out = []
    for i, x in enumerate(split_blocks(plaintext)):
        s = aes_enc_block(key, _int_to_block(counter + i))
        out.append(xor(x, s[:len(x)]))
    return iv + b"".join(out)

def ctr_decrypt(key: bytes, ciphertext: bytes) -> bytes:
    if len(ciphertext) < BLOCK:
        raise ValueError("Ciphertext must contain a 16-byte initial counter")
    iv, body = ciphertext[:BLOCK], ciphertext[BLOCK:]
    counter = int.from_bytes(iv, "big")
    out = []
    for i, y in enumerate(split_blocks(body)):
        s = aes_enc_block(key, _int_to_block(counter + i))
        out.append(xor(y, s[:len(y)]))
    return b"".join(out)
